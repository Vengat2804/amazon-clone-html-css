# 🛒 Amazon Clone (HTML + CSS)

A simple static clone of the Amazon homepage using only **HTML** and **CSS**.  
This is a beginner-level front-end project to demonstrate layout design, UI structure, and responsive elements.

## 🔥 Features

- Responsive Header with Search Bar
- Product Cards Grid
- Simple Footer
- Clean layout inspired by Amazon.in

## 🧰 Built With

- HTML5
- CSS3

## 📸 Screenshot

![Amazon Clone Screenshot](https://via.placeholder.com/800x400)

> *(Replace with your own screenshot once deployed)*

## 🚀 How to Run

1. Clone the repo:
```bash
git clone https://github.com/yourusername/amazon-clone-html-css.git
```

2. Open `index.html` in your browser.

## 💡 Author

**Vengatesh M**  
[LinkedIn](https://www.linkedin.com/in/YOURPROFILE) | [GitHub](https://github.com/YOURUSERNAME)

---

## 📌 License

This project is open-source. Feel free to fork and improve!
